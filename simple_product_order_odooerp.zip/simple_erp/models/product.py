from odoo import models, fields

class Product(models.Model):
    _name = 'simple.erp.product'
    _description = 'ERP Product'

    name = fields.Char(string='Product Name', required=True)
    price = fields.Float(string='Price')
    quantity = fields.Integer(string='Stock Quantity')
