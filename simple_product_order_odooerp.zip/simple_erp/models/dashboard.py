from odoo import models, fields, api

class SimpleERPDashboard(models.Model):
    _name = 'simple.erp.dashboard'
    _description = 'Simple ERP Dashboard'
    _auto = False

    total_products = fields.Integer(string='Total Products')
    total_orders = fields.Integer(string='Total Orders')
    total_sales = fields.Float(string='Total Sales')
    total_payments = fields.Float(string='Total Payments')

    @api.model
    def get_dashboard_data(self):
        product_count = self.env['simple.erp.product'].search_count([])
        order_count = self.env['simple.erp.order'].search_count([])
        total_sales = sum(self.env['simple.erp.order'].search([]).mapped('total_amount'))
        total_payments = sum(self.env['simple.erp.payment'].search([]).mapped('amount'))

        return {
            'total_products': product_count,
            'total_orders': order_count,
            'total_sales': total_sales,
            'total_payments': total_payments,
        }

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        data = self.get_dashboard_data()
        return [data]
