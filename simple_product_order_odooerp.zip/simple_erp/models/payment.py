from odoo import models, fields, api

class Payment(models.Model):
    _name = 'simple.erp.payment'
    _description = 'ERP Payment'

    order_id = fields.Many2one('simple.erp.order', string='Order', required=True)
    payment_type = fields.Selection([
        ('cash', 'Cash'),
        ('ewallet', 'E-Wallet'),
        ('bank_transfer', 'Bank Transfer')
    ], string='Payment Type', required=True)

    amount = fields.Float(string='Amount', required=True)
    phone_number = fields.Char(string='Phone Number')  # for e-wallet
    bank_name = fields.Char(string='Bank Name')        # for transfer
    bank_reference = fields.Char(string='Bank Reference')  # for transfer

    @api.onchange('order_id')
    def _onchange_order_id(self):
        if self.order_id:
            self.amount = self.order_id.total_amount
