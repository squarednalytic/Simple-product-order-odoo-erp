from odoo import models, fields, api

class Order(models.Model):
    _name = 'simple.erp.order'
    _description = 'ERP Order'

    customer_name = fields.Char(string='Customer Name', required=True)
    order_line_ids = fields.One2many('simple.erp.order.line', 'order_id', string='Order Lines')
    payment_ids = fields.One2many('simple.erp.payment', 'order_id', string='Payments')
    total_amount = fields.Float(string='Total', compute='_compute_total', store=True)

    @api.depends('order_line_ids.subtotal')
    def _compute_total(self):
        for order in self:
            order.total_amount = sum(line.subtotal for line in order.order_line_ids)

class OrderLine(models.Model):
    _name = 'simple.erp.order.line'
    _description = 'ERP Order Line'

    order_id = fields.Many2one('simple.erp.order', string='Order')
    product_id = fields.Many2one('simple.erp.product', string='Product')
    quantity = fields.Integer(string='Quantity', default=1)
    price_unit = fields.Float(string='Unit Price')
    subtotal = fields.Float(string='Subtotal', compute='_compute_subtotal', store=True)

    @api.depends('quantity', 'price_unit')
    def _compute_subtotal(self):
        for line in self:
            line.subtotal = line.quantity * line.price_unit
