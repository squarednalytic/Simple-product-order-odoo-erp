{
    "name": "Simple ERP",
    "version": "1.0",
    "summary": "Basic ERP with products, orders, payments and dashboard",
    "author": "ChatGPT",
    "depends": ["base"],
    "category": "Tools",
    "data": [
        "security/ir.model.access.csv",
        "views/product_views.xml",
        "views/order_views.xml",
        "views/payment_views.xml",
        "views/dashboard_views.xml"
    ],
    "installable": True,
    "application": True
}
